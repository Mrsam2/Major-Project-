import tensorflow as tf
import numpy as np
import joblib
from flask import Flask, request, jsonify

app = Flask(__name__)

# Load model and encoders
interpreter = tf.lite.Interpreter(model_path="disease_model.tflite")
interpreter.allocate_tensors()
mlb = joblib.load("symptom_encoder.pkl")
le = joblib.load("disease_encoder.pkl")

input_details = interpreter.get_input_details()
output_details = interpreter.get_output_details()

@app.route('/predict', methods=['POST'])
def predict():
    data = request.json
    symptoms = data.get('symptoms', [])
    
    # Transform symptoms
    symptoms_vector = mlb.transform([symptoms])
    
    # Run inference
    interpreter.set_tensor(input_details[0]['index'], np.array(symptoms_vector, dtype=np.float32))
    interpreter.invoke()
    output = interpreter.get_tensor(output_details[0]['index'])
    predicted_class = np.argmax(output)

    result = le.inverse_transform([predicted_class])[0]
    return jsonify({"prediction": result})

if __name__ == "__main__":
    app.run(debug=True)
